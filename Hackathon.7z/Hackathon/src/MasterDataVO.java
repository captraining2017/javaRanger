
public class MasterDataVO {
	private int custId;
	private String custName;
	private double salary;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String toString() {
		return "MasterDataVO [custId=" + custId + ", custName=" + custName
				+ ", salary=" + salary + "]";
	}
	
	
}
