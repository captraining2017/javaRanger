import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class MasterData {
public static void main(String[] args) throws IOException {
	 
	double random=0;   
	MasterDataVO dataset;
	int count=0;
	BufferedReader br = new BufferedReader(new FileReader("data1.txt"));
	List list = new ArrayList();
	
	
		
		try {
			for (int i=1;i<=100;i++)
			{
				
			dataset = new MasterDataVO();
			// custId
			dataset.setCustId(i);
			
			System.out.println(dataset.getCustId());
			//custName
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	        
	        while (line != null) {
	        	count++;
	        	if(count==i){
	        	dataset.setCustName(line); 
	        	System.out.println(dataset.getCustName());
	        	break;
	        	}
	        }
	        //salary
	        if(i<=30)
	        {
	         random = Math.random() * 500000 + 1;
	        
	        //System.out.println(dataset.getSalary());
	        }
	        if (i>30 && i<=70)
	        {
	        	  random = Math.random() * 1000000 + 500000;
	        	 // dataset.setSalary(random);
	        }
	        else if(i>70 && i<=100)
	        {
	        	  random = Math.random() * 2000000 + 1000000;
	        }
	        
	        dataset.setSalary(random);
	        //
	        list.add(dataset);
	        System.out.println(dataset);
			}
	    } finally {
	        br.close();
	    }
	
		
	
	
}
	
}
