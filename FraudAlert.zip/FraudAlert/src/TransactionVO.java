import java.util.Date;


public class TransactionVO {
private	int custId;
private long transactionId;
private Date transactionDate;
private long transactionAmount;
public int getCustId() {
	return custId;
}
public void setCustId(double custId) {
	this.custId = (int) custId;
}
public long getTransactionId() {
	return transactionId;
}
public void setTransactionId(long transactionId) {
	this.transactionId = transactionId;
}
public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public long getTransactionAmount() {
	return transactionAmount;
}
public void setTransactionAmount(long transactionAmount) {
	this.transactionAmount = transactionAmount;
}
public String toString() {
	return "TransactionVO [custId=" + custId + ", transactionId="
			+ transactionId + ", transactionDate=" + transactionDate
			+ ", transactionAmount=" + transactionAmount + "]";
}


}
