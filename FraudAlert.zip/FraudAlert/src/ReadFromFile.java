import java.io.BufferedReader;


public class ReadFromFile {
	public static void main(){
		
	}

}
