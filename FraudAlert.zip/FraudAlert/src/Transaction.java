import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class Transaction {
	public static long main(String args[]){
		 
		 ArrayList transactionList=new ArrayList();
		 TransactionVO transaction;
		 
		double random = (int) (Math.random() * 100  +1); //custId
		long Random = Math.round(Math.random() * 1000000) - 1000000;//TranscationId
		
		 //custId
		 for(int i=0; i<100; i++) {
			 transaction = new TransactionVO();
			 transaction.setCustId(random);
			 transactionList.add(transaction);
			 
		 }
		//TranscationId
		 
		 for(int i=0; i<500000; i++) {
			 transaction = new TransactionVO();
			 transaction.setTransactionId(Random);
			 transactionList.add(transaction);
			 
		 }
		 //transactionAmount
		 
		 for (int i = 0; i < 1000000; i++) {
				System.out.println(gettransactionAmount(1000, 20000));
		 }
		 int gettransactionAmount(long min, long max); {

				if (min >= max) {
					throw new IllegalArgumentException("max must be greater than min");
				}

				Random r = new Random();
				return r.nextInt() + min;
			}

		 
		
		
		 
		
		
			 
		 
		 
		 
		 
	}

	private static char[] gettransactionAmount(int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}

}
